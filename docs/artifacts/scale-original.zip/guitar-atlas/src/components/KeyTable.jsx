import { useState } from "react";
import { scalePitchClasses } from "../theory/scales";

const ALL_KEYS = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
const SCALE_OPTIONS = [
	"major",
	"natural minor",
	"melodic minor",
	"harmonic minor",
	"dorian",
	"mixolydian",
	"lydian",
	"phrygian",
	"locrian",
	"major pentatonic",
	"minor pentatonic",
	"whole tone",
	"diminished",
];

export default function KeyTable() {
	const [open, setOpen] = useState(true);
	const [scaleName, setScaleName] = useState("major");

	return (
		<div className='mt-6 border border-neutral-800 rounded-lg'>
			{/* Header bar for the whole KeyTable */}
			<div className='flex items-end gap-4 p-3 bg-neutral-900/40 rounded-t-lg'>
				<button
					className='px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-sm'
					onClick={() => setOpen((v) => !v)}>
					{open ? "Hide" : "Show"}
				</button>

				<div>
					<label className='block text-xs mb-1 opacity-70'>Scale</label>
					<select
						value={scaleName}
						onChange={(e) => setScaleName(e.target.value)}
						className='bg-neutral-900 border border-neutral-700 rounded px-2 py-1 text-sm'>
						{SCALE_OPTIONS.map((s) => (
							<option key={s} value={s}>
								{s}
							</option>
						))}
					</select>
				</div>

				<div className='text-xs opacity-60'>Notes will appear below.</div>
			</div>

			{/* Table section below */}
			{open && (
				<div className='p-3 overflow-x-auto'>
					<table className='min-w-[480px] w-full text-sm'>
						<thead className='text-left opacity-70'>
							<tr className='border-b border-neutral-800'>
								<th className='py-2 pr-4'>Key</th>
								<th className='py-2 pr-4'>Root</th>
								<th className='py-2'>Notes</th>
							</tr>
						</thead>
						<tbody>
							{ALL_KEYS.map((k) => {
								const { notes } = scalePitchClasses(k, scaleName);
								const notesStr = notes.join(" ");

								return (
									<tr key={k} className='border-b border-neutral-900/60'>
										<td className='py-2 pr-4 font-medium'>
											{k} {scaleName}
										</td>
										<td className='py-2 pr-4'>{k}</td>
										<td className='py-2'>
											<span className='font-mono'>{notesStr}</span>
										</td>
									</tr>
								);
							})}
						</tbody>
					</table>
				</div>
			)}
		</div>
	);
}
