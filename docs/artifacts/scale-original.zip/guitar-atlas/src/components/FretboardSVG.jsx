export default function FretboardSVG({
	strings,
	frets,
	dots,
	width = 900,
	height = 220,
	dark = true,
}) {
	const margin = 20;
	const W = width - margin * 2;
	const H = height - margin * 2;

	// open strings
	const boardWidth = W * 0.9;
	const openArea = W - boardWidth;
	const nutX = openArea;

	const stringGap = H / (strings - 1);
	const fretGap = boardWidth / frets;

	function stringY(stringIdx) {
		return stringIdx * stringGap;
	}
	function fretCenterX(fret) {
		return nutX + (fret - 0.5) * fretGap;
	}

	function openStringX() {
		return nutX * 0.5;
	}
	const theme =
		dark ?
			{
				bg: "#0b0b0b",
				line: "#777",
				dot: "#41b6e6",
				root: "#ef476f",
				text: "#fff",
			}
		:	{
				bg: "#fff",
				line: "#333",
				dot: "#2b8a3e",
				root: "#d00000",
				text: "#111",
			};

	return (
		<svg
			viewBox={`0 0 ${width} ${height}`}
			width={width}
			height={height}
			style={{ background: theme.bg, borderRadius: 12 }}>
			<g transform={`translate(${margin},${margin})`}>
				{Array.from({ length: strings }).map((_, s) => (
					<line
						key={`s${s}`}
						x1={0}
						y1={s * stringGap}
						x2={W}
						y2={s * stringGap}
						stroke={theme.line}
						strokeWidth={1.5}
					/>
				))}
				{Array.from({ length: frets + 1 }).map((_, f) => (
					<line
						key={`f${f}`}
						x1={nutX + f * fretGap}
						y1={0}
						x2={nutX + f * fretGap}
						y2={H}
						stroke={theme.line}
						strokeWidth={f === 0 ? 3 : 1}
					/>
				))}
				{dots.map((d, i) => {
					const isOpen = d.fret === 0;
					const cx = isOpen ? openStringX() : fretCenterX(d.fret);
					const cy = stringY(d.stringIdx);
					const isRoot = d.isRoot ?? d.degree === 0;

					return (
						<g key={i}>
							<circle cx={cx} cy={cy} r={8} fill={isRoot ? theme.root : theme.dot} />
							{d.label && (
								<text x={cx} y={cy + 4} textAnchor='middle' fontSize={12} fill={theme.text}>
									{d.label}
								</text>
							)}
						</g>
					);
				})}
				{[3, 5, 7, 9].map((f) => (
					<circle key={f} cx={fretCenterX(f)} cy={H / 2} r={5} fill='white' />
				))}
			</g>
		</svg>
	);
}
