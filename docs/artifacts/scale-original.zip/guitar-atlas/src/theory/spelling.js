export function labelForPC(pc, degreePCs) {
	const i = degreePCs.indexOf(pc);
	if (i === -1) return "";
	const labels = ["R", "2", "3", "4", "5", "6", "7"];
	return labels[i] ?? String(i + 1);
}
