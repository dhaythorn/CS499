// Represents the guitar neck and finds where notes appear
export function noteAt(stringIdx, fret, layout) {
	return layout.tuning[stringIdx] + layout.capo + fret;
}
export function positionsForPitchClasses(
	pcs,
	layout,
	range = [0, layout.frets]
) {
	const out = [];
	for (let s = 0; s < layout.strings; s++) {
		for (let f = range[0]; f <= range[1]; f++) {
			const midi = noteAt(s, f, layout);
			const pc = ((midi % 12) + 12) % 12;
			if (pcs.has(pc)) {
				out.push({ stringIdx: s, fret: f, midi, pc });
			}
		}
	}
	return out;
}
