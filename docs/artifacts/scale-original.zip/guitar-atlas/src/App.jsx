import { useMemo, useState } from "react";
import FretboardSVG from "./components/FretboardSVG";
import { positionsForPitchClasses } from "./theory/neck";
import { scalePitchClasses } from "./theory/scales";
import { labelForPC } from "./theory/spelling";
import KeyTable from "./components/KeyTable";
import { Note } from "@tonaljs/tonal";

const STANDARD_E = [40, 45, 50, 55, 59, 64]; // E2 A2 D3 G3 B3 E4

export default function App() {
	const [root, setRoot] = useState("C");
	const [scaleName, setScaleName] = useState("major");
	const layout = { strings: 6, frets: 12, tuning: STANDARD_E, capo: 0 };

	const { dots, notesList } = useMemo(() => {
		const { pcs, degreePCs, notes } = scalePitchClasses(root, scaleName);
		const rootPc = Note.get(root).chroma;
		const pos = positionsForPitchClasses(pcs, layout, [0, 12]);
		const dots = pos.map((p) => {
			const degreeIndex = degreePCs.indexOf(p.pc);
			const isRoot = p.pc === rootPc;

			return {
				stringIdx: p.stringIdx,
				fret: p.fret,
				degree: degreeIndex,
				isRoot,
				label: isRoot ? "R" : labelForPC(p.pc, degreePCs),
			};
		});
		return { dots, notesList: notes.join(" ") };
	}, [root, scaleName]);

	return (
		<div className='min-h-screen p-6'>
			<h1 className='text-2xl font-semibold mb-4'>Guitar Atlas — Scale Explorer</h1>

			<div className='mb-4 flex gap-4 items-end'>
				<div>
					<label className='block text-sm mb-1'>Root</label>
					<select
						value={root}
						onChange={(e) => setRoot(e.target.value)}
						className='bg-neutral-900 border border-neutral-700 rounded px-2 py-1'>
						{["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"].map((k) => (
							<option key={k}>{k}</option>
						))}
					</select>
				</div>
				<div>
					<label className='block text-sm mb-1'>Scale</label>
					<select
						value={scaleName}
						onChange={(e) => setScaleName(e.target.value)}
						className='bg-neutral-900 border border-neutral-700 rounded px-2 py-1'>
						{[
							"major",
							"natural minor",
							"melodic minor",
							"harmonic minor",
							"dorian",
							"mixolydian",
							"lydian",
							"phrygian",
							"locrian",
							"major pentatonic",
							"minor pentatonic",
							"whole tone",
							"diminished",
						].map((s) => (
							<option key={s}>{s}</option>
						))}
					</select>
				</div>
				<div className='text-sm opacity-80'>
					<div>
						<span className='opacity-60'>Notes:</span> {notesList}
					</div>
				</div>
			</div>

			<FretboardSVG strings={6} frets={12} dots={dots} />
			<KeyTable />
		</div>
	);
}
