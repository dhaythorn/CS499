import { Note, Scale } from "@tonaljs/tonal";

export function scalePitchClasses(root, scaleName) {
	const info = Scale.get(`${root} ${scaleName}`);
	const pcs = new Set(info.notes.map((n) => Note.get(n).chroma));
	const degreePCs = info.notes.map((n) => Note.get(n).chroma);

	return { pcs, degreePCs, notes: info.notes };
}
